//Backup in case I mess up the OG regression.js file
x = [1, 2, 3, 4, 5]
y = [2,16,54,128,250]

//Helper Functions

let sum = function(x) {
	return x.reduce((total, num) => total + num, 0)
}
let zip = function(x, y) {
  //js implementation of python's zip
	return x.map(function(e, i) {
		return [e, y[i]];
	});
}
let ln = function(x) {
  //Math.log(x) is acutally ln(x)
	return x.map(x => Math.log(x))
}
let matrixSolver = function(A) {
  //substack github
  //returns rref matrix
	var rows = A.length;
	var columns = A[0].length;
	var lead = 0;
	for (var k = 0; k < rows; k++) {
		if (columns <= lead) return;
		var i = k;
		while (A[i][lead] === 0) {
			i++;
			if (rows === i) {
				i = k;
				lead++;
				if (columns === lead) return;
			}
		}
		var irow = A[i],
			krow = A[k];
		A[i] = krow, A[k] = irow;
		var val = A[k][lead];
		for (var j = 0; j < columns; j++) {
			A[k][j] /= val;
		}
		for (var i = 0; i < rows; i++) {
			if (i === k) continue;
			val = A[i][lead];
			for (var j = 0; j < columns; j++) {
				A[i][j] -= val * A[k][j];
			}
		}
		lead++;
	}
	return A;
};

//Regression Functions
//Formulas obtained from planetcalc

let linear = function(x, y) {
	let xy = zip(x, y).map(a => a[0] * a[1])
	let n = x.length
	m = (sum(x) * sum(y) - n * sum(xy)) / (sum(x) ** 2 - n * sum(x.map(x => x ** 2)))
	b = (sum(x) * sum(xy) - sum(x.map(x => x ** 2)) * sum(y)) / (sum(x) ** 2 - n * sum(x.map(x => x ** 2)))
	return [m, b]
}
let polynomial = function(x, y, order) {
	n = x.length
	matrix = []
	for (var i = order; i <= order * 2; i++) {
		row = []
		for (var j = 0; j <= order; j++) {
			row.push(i - j)
			console.log(i + "," + j)
		}
		row.push(row[row.length - 1])
		matrix.push(row)
		console.log(row)
	}
	for (var i = 0; i < matrix.length; i++) {
		for (var j = 0; j < matrix[i].length - 1; j++) {
			matrix[i][j] = sum(x.map(x => x ** matrix[i][j]))
		}
		matrix[i][matrix[i].length - 1] = sum(zip(x, y).map(a => a[0] ** matrix[i][matrix[i].length - 1] * a[1]))
	}
	matrix[0][order] = n
	console.log(matrixSolver(matrix))
}
let power = function(x, y) {
	let n = x.length
	b = (n * sum(zip(x, y).map(a => Math.log(a[0]) * Math.log(a[1]))) - sum(ln(x)) * sum(ln(y))) / (n * sum(ln(x).map(x => x ** 2)) - (sum(ln(x))) ** 2)
	a = ((1 / n) * sum(ln(y))) - ((b / n) * sum(ln(x)))
	a = Math.exp(a)
	console.log("y = a*(x^b)")
	return [a, b]
}
let ab_exponential = function(x, y) {
	n = x.length
	b = (n * sum(zip(x, y).map(a => a[0] * Math.log(a[1]))) - sum(x) * sum(ln(y))) / (n * sum(x.map(x => x ** 2)) - (sum(x)) ** 2)
	b = Math.exp(b)
	a = (1 / n) * sum(ln(y)) - (Math.log(b) / n) * sum(x)
	a = Math.exp(a)
	console.log("y = a*(b^x)")
	return [a, b]
}
let logarithmic = function(x, y) {
	n = x.length
	b = (n * sum(zip(y, x).map(a => a[0] * Math.log(a[1]))) - sum(ln(x)) * sum(y)) / (n * sum(ln(x).map(x => x ** 2)) - sum(ln(x)) ** 2)
	a = (1 / n) * sum(y) - (b / n) * sum(ln(x))
	console.log("y=a+bln(x)")
	return [a, b]
}