let domain_input = document.getElementById("domain-input");
let range_input = document.getElementById("range-input");
let calculate_button = document.getElementById("calculate-button");
let precision_input = document.getElementById("precision-input")

let regression_type_input = document.getElementById("regression-type-input");

let reg_result = document.getElementById("reg-result");
let reg_table = document.getElementById("reg-table");

//Function for each regression type
let createRegressionElement = function(domain, range, regEq) {
    let container = document.createElement("div")
    container.id = `${regEq.type}-details-container`

    let equation = document.createElement("strong")
    equation.innerText = regEq.toString()

    let stdError = document.createElement("p")
    stdError.innerText = regEq.getstdErr(domain, range)

    container.appendChild(equation)
    container.appendChild(stdError)

    return container
}

//List all regression options with checboxes
for (type in regression) {
    let container = document.createElement("div")

    let checkbox = document.createElement("input")
    checkbox.type = "checkbox"
    checkbox.id = type + "-input"
    checkbox.checked = true

    let label = document.createElement("label")
    label.innerText = type
    label.htmlFor = type

    container.appendChild(checkbox)
    container.appendChild(label)

    /*
    regression_type_input.appendChild(checkbox)
    regression_type_input.appendChild(label)
    */
   regression_type_input.append(container)
}

//Calculate Button Event Handler
calculate_button.onclick = function(event) {
    domain = domain_input.value.split(",").map(x=>+x);
    range = range_input.value.split(",").map(x=>+x);
    precision = +precision_input.value

    //Initialize Function Table
    let headRow = reg_table.insertRow(0)
    let cell = headRow.insertCell(0)
    cell.outerHTML = "<th>x</th>"
    cell = headRow.insertCell(1)
    cell.outerHTML = "<th>range</th>"

    for (var x = 1; x <= domain.length; x++) {
        reg_table.insertRow(x)
        reg_table.rows[x].insertCell(0)
        reg_table.rows[x].cells[0].innerText = domain[x-1]

        reg_table.rows[x].insertCell(1)
        reg_table.rows[x].cells[1].innerText = range[x-1]
    }
    
    reg_result.innerHTML = ""
    regEqs = []
    for (type in regression) {
        if (document.getElementById(type + "-input").checked) {
            //List Equations
            let regEq = regression[type](domain, range)
            regEq.precision = precision
            regEqs.push(regEq)
            reg_result.appendChild(createRegressionElement(domain, range, regEq))

            //Create function table column
            //Column Header
            cell = headRow.insertCell(-1)
            cell.outerHTML = `<th>${type}</th>`
            //Populate Column Values
            for (var x = 1; x <= domain.length; x++) {
                index = reg_table.rows[x].cells.length
                reg_table.rows[x].insertCell(index)
                reg_table.rows[x].cells[index].innerText = regEq.predict(domain[x-1])
            }
        }
    }


}
