let domain_input = document.getElementById("domain-input");
let range_input = document.getElementById("range-input");
let calculate_button = document.getElementById("calculate-button");
let precision_input = document.getElementById("precision-input")

let regression_type_input = document.getElementById("regression-type-input");

let reg_result = document.getElementById("reg-result");
let reg_table = document.getElementById("reg-table");

let reg_graphs = document.getElementById("reg-graphs");

//Event listener for enter key
domain_input.addEventListener("keyup", ({keyCode}) => {
    if (keyCode === 13) {
      calculate_button.click();
    }
  });
range_input.addEventListener("keyup", ({keyCode}) => {
    if (keyCode === 13) {
        calculate_button.click();
    }
});

//Function for each regression type create element
let createRegressionElement = function(domain, range, regEq) {
    let container = document.createElement("div")
    container.classList.add("reg-detail-container")
    container.id = `${regEq.type}-details-container`

    /*
    let equation = document.createElement("strong")
    equation.innerText = regEq.toString()
    */

    let label = document.createElement("h4")
    label.innerText = regEq.type

    let equation = document.createElement("span")
    katex.render(regEq.toString(), equation);

    let stdError = document.createElement("p")
    //stdError.innerText = "Std Error: " + regEq.getstdErr(domain, range)
    stdError.innerHTML = `Std Error: <b>${regEq.getstdErr(domain, range)}%</b>`

    let corrCoeff = document.createElement("p")
    //corrCoeff.innerText = "Corr Coeff: " + regEq.getcorrCoeff(domain, range)
    corrCoeff.innerHTML = `Corr Coeff: <b>${regEq.getcorrCoeff(domain, range)}</b>`

    container.appendChild(label)
    container.appendChild(equation)
    container.appendChild(corrCoeff)
    container.appendChild(stdError)

    return container
}

let createRegressionGraph = function(domain, range, regEqs) {
    //Colors taken from learnui.design/tools/data-color-picker
    colors = ['#003f5c', '#374c80', '#7a5195', '#bc5090', '#ef5675', '#ff764a', '#ffa600'] 
    config = {
        type: "scatter",
        options: {
            scales: {
                xAxes: [{
                    ticks: {
                        suggestedMin: domain[0],
                        max: domain[domain.length-1]
                    }
                }],
                yAxes: [{
                    ticks: {
                        suggestedMin: range[0],
                        suggestedMax: range[range.length-1]
                    }
                }]
            }
        },
        data: {
            datasets: [
                {
                    //Uses zip from regression.js
                    data: zip(domain,range).map(a => ({
                        x: a[0],
                        y: a[1]
                    })),
                    fill: false,
                    label: "Actual Data",
                    backgroundColor: colors[0],
                    borderColor: colors[0],
                    order: 0,
                    pointStyle: "cross",
                    radius: 10
                }
            ]
        }
    }

    for (var i = 0; i<regEqs.length; i++) {
        dataset = {
            data: domain.map(x => ({
                x,
                y:regEqs[i].predict(x)
            })),
            fill: false,
            label: regEqs[i].type,
            backgroundColor: colors[i+1],
            borderColor: colors[i+1],
            showLine: true
        }
        config.data.datasets.push(dataset)
    }
    return config
}

//List all regression options with checboxes
for (type in regression) {
    let container = document.createElement("div")

    let checkbox = document.createElement("input")
    checkbox.type = "checkbox"
    checkbox.id = type + "-input"
    checkbox.checked = true

    let label = document.createElement("label")
    label.innerText = type
    label.htmlFor = type

    container.appendChild(checkbox)
    container.appendChild(label)

    /*
    regression_type_input.appendChild(checkbox)
    regression_type_input.appendChild(label)
    */
   regression_type_input.append(container)
}

//Calculate Button Event Handler
calculate_button.onclick = function(event) {
    domain = domain_input.value.split(",").map(x=>+x);
    range = range_input.value.split(",").map(x=>+x);
    precision = +precision_input.value

    //Initialize Function Table
    reg_table.innerHTML = ""
    let headRow = reg_table.insertRow(0)
    let cell = headRow.insertCell(0)
    cell.outerHTML = "<th>x</th>"
    cell = headRow.insertCell(1)
    cell.outerHTML = "<th>actual</th>"

    for (var x = 1; x <= domain.length; x++) {
        reg_table.insertRow(x)
        reg_table.rows[x].insertCell(0)
        reg_table.rows[x].cells[0].innerText = domain[x-1]

        reg_table.rows[x].insertCell(1)
        reg_table.rows[x].cells[1].innerText = range[x-1]
    }
    
    reg_result.innerHTML = ""
    regEqs = []
    for (type in regression) {
        if (document.getElementById(type + "-input").checked) {
            //List Equations
            let regEq = regression[type](domain, range)
            regEq.precision = precision
            regEqs.push(regEq)
            reg_result.appendChild(createRegressionElement(domain, range, regEq))

            //Create function table column
            //Column Header
            cell = headRow.insertCell(-1)
            cell.outerHTML = `<th>${type}</th>`
            //Populate Column Values
            for (var x = 1; x <= domain.length; x++) {
                index = reg_table.rows[x].cells.length
                reg_table.rows[x].insertCell(index)
                reg_table.rows[x].cells[index].innerText = regEq.predict(domain[x-1])
            }
        }
    }

    //Draw Graph
    let lineChart = new Chart(reg_graphs, createRegressionGraph(domain, range, regEqs))
}